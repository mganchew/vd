@extends('layouts.app')

@section('content')
<div class="row">
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%201&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%202&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%203&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%204&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%205&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
    <iframe class="calendars" src="https://calendar.google.com/calendar/embed?title=%D0%A4%D1%83%D1%82%D0%B1%D0%BE%D0%BB%205%20%D0%B8%D0%B3%D1%80%D0%B8%D1%89%D0%B5%206&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;ctz=Europe%2FSofia" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
</div>
@endsection