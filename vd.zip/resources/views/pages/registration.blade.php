@extends('layouts.app')

@section('content')

    <div class="row text-center">
        <h3>Телефон за резервации:</h3>
           <h1>087 7761899</h1>
    </div>

@endsection