@extends('layouts.app')

@section('content')
    <img class="bg" src="/images/background/background3.jpg" alt="">

    <div class="row">
        <div class="col-sm-4">

        </div>
        <div class="col-sm-4">

        </div>
        <div class="col-sm-4 text-center">
            <h1 class="homepage-text">Игрище за минифутбол <br></h1>
            <img class="img-circle" style="width: 40%;" src="/images/brand.jpg" alt="">
        </div>

    </div>


@endsection