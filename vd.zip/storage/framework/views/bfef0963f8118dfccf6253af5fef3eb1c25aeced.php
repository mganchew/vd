<?php $__env->startSection('content'); ?>

    <div class="row text-center">
        <h3>Телефон за резервации:</h3>
           <h1>087 7761899</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>